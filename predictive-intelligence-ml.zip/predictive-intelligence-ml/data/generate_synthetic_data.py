"""
Generates a synthetic tabular dataset for a binary classification "predictive
intelligence" task (e.g. churn / risk / failure prediction). Replace this with
a loader for your real dataset when you have one -- just keep the output at
data/dataset.csv with a target column named 'target'.
"""
import numpy as np
import pandas as pd
from pathlib import Path

RNG = np.random.default_rng(42)
N_ROWS = 5000

def generate():
    df = pd.DataFrame({
        "customer_age": RNG.integers(18, 80, N_ROWS),
        "account_tenure_months": RNG.integers(1, 240, N_ROWS),
        "monthly_spend": RNG.normal(120, 45, N_ROWS).clip(0),
        "support_tickets": RNG.poisson(1.5, N_ROWS),
        "num_products": RNG.integers(1, 6, N_ROWS),
        "satisfaction_score": RNG.normal(7, 2, N_ROWS).clip(0, 10),
        "region": RNG.choice(["north", "south", "east", "west"], N_ROWS),
        "plan_type": RNG.choice(["basic", "standard", "premium"], N_ROWS, p=[0.4, 0.4, 0.2]),
    })

    # inject some missingness to make preprocessing meaningful
    for col in ["monthly_spend", "satisfaction_score"]:
        mask = RNG.random(N_ROWS) < 0.03
        df.loc[mask, col] = np.nan

    # synthetic target with a real signal + noise
    logit = (
        -0.03 * df["satisfaction_score"].fillna(7)
        + 0.02 * df["support_tickets"]
        - 0.01 * df["account_tenure_months"]
        + 0.005 * df["monthly_spend"].fillna(120)
        + RNG.normal(0, 1, N_ROWS)
    )
    prob = 1 / (1 + np.exp(-logit))
    df["target"] = (prob > np.median(prob)).astype(int)

    out_path = Path(__file__).parent / "dataset.csv"
    df.to_csv(out_path, index=False)
    print(f"Wrote {len(df)} rows to {out_path}")

    # a small held-out sample with no target, for predict.py demo
    sample = df.drop(columns=["target"]).sample(10, random_state=1)
    sample.to_csv(Path(__file__).parent / "sample_new_records.csv", index=False)
    print("Wrote sample_new_records.csv for inference demo")

if __name__ == "__main__":
    generate()
