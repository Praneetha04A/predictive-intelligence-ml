"""Exploratory data analysis: summary stats + saved plots."""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from data_preprocessing import load_data, TARGET_COL

OUT_DIR = Path(__file__).resolve().parent.parent / "eda_output"


def run_eda():
    OUT_DIR.mkdir(exist_ok=True)
    df = load_data()

    print("Shape:", df.shape)
    print("\nMissing values:\n", df.isna().sum())
    print("\nTarget balance:\n", df[TARGET_COL].value_counts(normalize=True))

    numeric_df = df.select_dtypes(include="number")

    plt.figure(figsize=(8, 6))
    sns.heatmap(numeric_df.corr(), annot=True, fmt=".2f", cmap="coolwarm")
    plt.title("Feature correlation matrix")
    plt.tight_layout()
    plt.savefig(OUT_DIR / "correlation_matrix.png")
    plt.close()

    for col in numeric_df.columns:
        plt.figure(figsize=(5, 4))
        sns.histplot(df[col].dropna(), kde=True)
        plt.title(f"Distribution: {col}")
        plt.tight_layout()
        plt.savefig(OUT_DIR / f"dist_{col}.png")
        plt.close()

    print(f"\nEDA plots written to {OUT_DIR}/")


if __name__ == "__main__":
    run_eda()
