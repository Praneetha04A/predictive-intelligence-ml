"""Data loading + preprocessing: missing values, encoding, scaling."""
from pathlib import Path
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "dataset.csv"
TARGET_COL = "target"


def load_data(path: Path = DATA_PATH) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(
            f"{path} not found. Run `python data/generate_synthetic_data.py` first, "
            "or drop your own dataset.csv into data/."
        )
    return pd.read_csv(path)


def build_preprocessor(df: pd.DataFrame, target_col: str = TARGET_COL) -> ColumnTransformer:
    """Builds a scikit-learn ColumnTransformer that imputes, scales numeric
    features, and one-hot encodes categorical features."""
    feature_df = df.drop(columns=[target_col]) if target_col in df.columns else df
    numeric_cols = feature_df.select_dtypes(include="number").columns.tolist()
    categorical_cols = feature_df.select_dtypes(exclude="number").columns.tolist()

    numeric_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore")),
    ])

    return ColumnTransformer([
        ("num", numeric_pipeline, numeric_cols),
        ("cat", categorical_pipeline, categorical_cols),
    ])


if __name__ == "__main__":
    df = load_data()
    print(df.describe(include="all").T)
