"""Loads trained models and benchmarks them on the held-out test split."""
import time
from pathlib import Path
import joblib
import pandas as pd
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report,
)

MODEL_DIR = Path(__file__).resolve().parent.parent / "models"
TARGET_COL = "target"


def benchmark(name, y_true, y_pred, y_prob, latency_ms):
    print(f"\n=== {name} ===")
    print(classification_report(y_true, y_pred))
    print("Confusion matrix:\n", confusion_matrix(y_true, y_pred))
    print(f"Accuracy:  {accuracy_score(y_true, y_pred):.4f}")
    print(f"Precision: {precision_score(y_true, y_pred):.4f}")
    print(f"Recall:    {recall_score(y_true, y_pred):.4f}")
    print(f"F1:        {f1_score(y_true, y_pred):.4f}")
    print(f"ROC-AUC:   {roc_auc_score(y_true, y_prob):.4f}")
    print(f"Inference latency: {latency_ms:.2f} ms for {len(y_true)} rows "
          f"({latency_ms/len(y_true):.3f} ms/row)")


def evaluate_baseline(test_df):
    model = joblib.load(MODEL_DIR / "baseline_model.pkl")
    X_test, y_test = test_df.drop(columns=[TARGET_COL]), test_df[TARGET_COL]

    start = time.perf_counter()
    y_prob = model.predict_proba(X_test)[:, 1]
    latency_ms = (time.perf_counter() - start) * 1000
    y_pred = (y_prob >= 0.5).astype(int)

    benchmark("RandomForest baseline", y_test, y_pred, y_prob, latency_ms)


def evaluate_dnn(test_df):
    import tensorflow as tf
    model = tf.keras.models.load_model(MODEL_DIR / "dnn_model.keras")
    preprocessor = joblib.load(MODEL_DIR / "dnn_preprocessor.pkl")

    X_test, y_test = test_df.drop(columns=[TARGET_COL]), test_df[TARGET_COL]
    X_test_t = preprocessor.transform(X_test)
    if hasattr(X_test_t, "toarray"):
        X_test_t = X_test_t.toarray()

    start = time.perf_counter()
    y_prob = model.predict(X_test_t, verbose=0).ravel()
    latency_ms = (time.perf_counter() - start) * 1000
    y_pred = (y_prob >= 0.5).astype(int)

    benchmark("Keras DNN", y_test, y_pred, y_prob, latency_ms)


if __name__ == "__main__":
    test_df = pd.read_csv(MODEL_DIR / "test_split.csv")
    if (MODEL_DIR / "baseline_model.pkl").exists():
        evaluate_baseline(test_df)
    if (MODEL_DIR / "dnn_model.keras").exists():
        evaluate_dnn(test_df)
