"""Feature engineering: interaction + ratio features, and a feature-selection helper."""
import pandas as pd
from sklearn.feature_selection import SelectKBest, f_classif


def add_engineered_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if {"monthly_spend", "account_tenure_months"}.issubset(df.columns):
        df["lifetime_value_est"] = df["monthly_spend"].fillna(0) * df["account_tenure_months"]
    if {"support_tickets", "account_tenure_months"}.issubset(df.columns):
        df["tickets_per_month"] = df["support_tickets"] / df["account_tenure_months"].clip(lower=1)
    if {"num_products", "monthly_spend"}.issubset(df.columns):
        df["spend_per_product"] = df["monthly_spend"].fillna(0) / df["num_products"].clip(lower=1)
    return df


def select_top_k_features(X, y, k: int = 10):
    """Runs univariate feature selection (ANOVA F-value) on already-encoded
    numeric features and returns the selector + selected column indices."""
    selector = SelectKBest(score_func=f_classif, k=min(k, X.shape[1]))
    X_new = selector.fit_transform(X, y)
    return selector, X_new
