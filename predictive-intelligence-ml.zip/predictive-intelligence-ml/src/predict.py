"""CLI to run predictions on new records using the trained baseline model.

Usage:
    python src/predict.py --input data/sample_new_records.csv
"""
import argparse
from pathlib import Path
import joblib
import pandas as pd

from feature_engineering import add_engineered_features

MODEL_DIR = Path(__file__).resolve().parent.parent / "models"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="CSV of new records (no target column)")
    parser.add_argument("--output", default=None, help="Where to write predictions CSV")
    args = parser.parse_args()

    model = joblib.load(MODEL_DIR / "baseline_model.pkl")
    df = pd.read_csv(args.input)
    df_fe = add_engineered_features(df)

    probs = model.predict_proba(df_fe)[:, 1]
    preds = (probs >= 0.5).astype(int)

    result = df.copy()
    result["predicted_class"] = preds
    result["predicted_probability"] = probs.round(4)

    out_path = args.output or str(Path(args.input).with_name("predictions.csv"))
    result.to_csv(out_path, index=False)
    print(result)
    print(f"\nSaved predictions to {out_path}")


if __name__ == "__main__":
    main()
