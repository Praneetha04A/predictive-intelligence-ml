"""Trains a RandomForest baseline with hyperparameter tuning via GridSearchCV."""
import time
from pathlib import Path
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.pipeline import Pipeline

from data_preprocessing import load_data, build_preprocessor, TARGET_COL
from feature_engineering import add_engineered_features

MODEL_DIR = Path(__file__).resolve().parent.parent / "models"
PARAM_GRID = {
    "clf__n_estimators": [100, 200],
    "clf__max_depth": [None, 10, 20],
    "clf__min_samples_split": [2, 5],
}


def train():
    MODEL_DIR.mkdir(exist_ok=True)
    df = add_engineered_features(load_data())
    X, y = df.drop(columns=[TARGET_COL]), df[TARGET_COL]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    preprocessor = build_preprocessor(df, TARGET_COL)
    pipeline = Pipeline([
        ("preprocess", preprocessor),
        ("clf", RandomForestClassifier(random_state=42)),
    ])

    print("Running GridSearchCV hyperparameter tuning...")
    start = time.time()
    search = GridSearchCV(pipeline, PARAM_GRID, cv=5, scoring="roc_auc", n_jobs=-1)
    search.fit(X_train, y_train)
    elapsed = time.time() - start

    print(f"Best params: {search.best_params_}")
    print(f"Best CV ROC-AUC: {search.best_score_:.4f}")
    print(f"Tuning time: {elapsed:.1f}s")

    test_score = search.score(X_test, y_test)
    print(f"Held-out test accuracy: {test_score:.4f}")

    joblib.dump(search.best_estimator_, MODEL_DIR / "baseline_model.pkl")
    X_test.assign(**{TARGET_COL: y_test}).to_csv(MODEL_DIR / "test_split.csv", index=False)
    print(f"Saved model to {MODEL_DIR / 'baseline_model.pkl'}")


if __name__ == "__main__":
    train()
