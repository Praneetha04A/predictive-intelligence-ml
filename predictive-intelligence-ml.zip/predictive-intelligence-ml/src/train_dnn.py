"""Trains a Keras deep feed-forward neural network on the same preprocessed data."""
from pathlib import Path
import joblib
import numpy as np
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras import layers, models, callbacks

from data_preprocessing import load_data, build_preprocessor, TARGET_COL
from feature_engineering import add_engineered_features

MODEL_DIR = Path(__file__).resolve().parent.parent / "models"


def build_model(input_dim: int) -> tf.keras.Model:
    model = models.Sequential([
        layers.Input(shape=(input_dim,)),
        layers.Dense(128, activation="relu"),
        layers.Dropout(0.3),
        layers.Dense(64, activation="relu"),
        layers.Dropout(0.2),
        layers.Dense(32, activation="relu"),
        layers.Dense(1, activation="sigmoid"),
    ])
    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy", tf.keras.metrics.AUC(name="auc")])
    return model


def train():
    MODEL_DIR.mkdir(exist_ok=True)
    df = add_engineered_features(load_data())
    X, y = df.drop(columns=[TARGET_COL]), df[TARGET_COL]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    preprocessor = build_preprocessor(df, TARGET_COL)
    X_train_t = preprocessor.fit_transform(X_train)
    X_test_t = preprocessor.transform(X_test)
    if hasattr(X_train_t, "toarray"):
        X_train_t, X_test_t = X_train_t.toarray(), X_test_t.toarray()

    model = build_model(X_train_t.shape[1])
    early_stop = callbacks.EarlyStopping(patience=8, restore_best_weights=True)

    history = model.fit(
        X_train_t, y_train,
        validation_split=0.2,
        epochs=100,
        batch_size=32,
        callbacks=[early_stop],
        verbose=2,
    )

    test_loss, test_acc, test_auc = model.evaluate(X_test_t, y_test, verbose=0)
    print(f"Test accuracy: {test_acc:.4f} | Test AUC: {test_auc:.4f}")

    model.save(MODEL_DIR / "dnn_model.keras")
    joblib.dump(preprocessor, MODEL_DIR / "dnn_preprocessor.pkl")
    print(f"Saved DNN model to {MODEL_DIR / 'dnn_model.keras'}")


if __name__ == "__main__":
    train()
