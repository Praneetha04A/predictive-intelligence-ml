# AI-Driven Predictive Intelligence Using Machine Learning and Deep Learning

An end-to-end ML/DL pipeline for predictive analytics: data preprocessing, exploratory
data analysis, feature engineering, a supervised ML baseline, and a deep neural network,
with hyperparameter tuning, benchmarking, and inference on new data.

```bash
pip install -r requirements.txt
python data/generate_synthetic_data.py && python src/train_baseline.py
```

## Features

- **Data preprocessing**: missing-value handling, scaling, encoding
- **EDA**: automated summary stats + correlation/distribution plots
- **Feature engineering**: interaction features, polynomial terms, feature selection
- **Modeling**:
  - Baseline: `RandomForestClassifier` (scikit-learn) with `GridSearchCV` tuning
  - Deep learning: a Keras/TensorFlow feed-forward network
- **Benchmarking**: accuracy, precision/recall, F1, ROC-AUC, confusion matrix, latency
- **Inference**: a `predict.py` CLI for scoring new records

## Project structure

```
predictive-intelligence-ml/
├── data/
│   └── generate_synthetic_data.py   # creates a sample dataset (swap for your own CSV)
├── src/
│   ├── data_preprocessing.py
│   ├── eda.py
│   ├── feature_engineering.py
│   ├── train_baseline.py            # RandomForest + GridSearchCV
│   ├── train_dnn.py                 # Keras deep neural network
│   ├── evaluate.py
│   └── predict.py
├── models/                          # trained models saved here (.pkl / .h5)
├── requirements.txt
└── README.md
```

## Quickstart

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# 1. Generate/prepare data (or drop your own CSV into data/dataset.csv)
python data/generate_synthetic_data.py

# 2. Explore
python src/eda.py

# 3. Train the baseline model
python src/train_baseline.py

# 4. Train the deep learning model
python src/train_dnn.py

# 5. Evaluate + benchmark both
python src/evaluate.py

# 6. Run inference on new data
python src/predict.py --input data/sample_new_records.csv
```

## Notes

This repo ships with a synthetic dataset generator so it runs out of the box.
Swap `data/dataset.csv` for a real dataset and adjust `TARGET_COL` in
`src/data_preprocessing.py` to point this pipeline at your own predictive
intelligence problem.

## License

MIT
